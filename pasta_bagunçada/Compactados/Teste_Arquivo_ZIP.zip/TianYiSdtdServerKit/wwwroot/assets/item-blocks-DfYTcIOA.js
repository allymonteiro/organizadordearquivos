import{P as t}from"./index-CVjTEUHJ.js";const s=e=>t.get("/ItemBlocks",{params:e});export{s as g};
