import{P as s}from"./index-CVjTEUHJ.js";const e=()=>s.get("/Blacklist"),l=t=>s.post("/Blacklist/",t),r=t=>s.delete("/Blacklist/",{params:{playerIds:t}});export{l as a,r as d,e as g};
